-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2017 at 01:19 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `railway_reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `Admin_name` varchar(100) NOT NULL,
  `Admin_id` varchar(100) NOT NULL,
  `Admin_pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`Admin_name`, `Admin_id`, `Admin_pass`) VALUES
('Abu Rayhan Ahmad', 'rayhan50001', '12345'),
('sharif', 'sharif', '123456'),
('Azijul Hakim Siam', 'siam1234', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `pnr`
--

CREATE TABLE `pnr` (
  `PNR_no` int(11) NOT NULL,
  `Train_no` varchar(100) NOT NULL,
  `Train_name` varchar(100) NOT NULL,
  `Train_class` varchar(100) NOT NULL,
  `Train_seat` int(11) NOT NULL,
  `Train_start` varchar(100) NOT NULL,
  `Train_end` varchar(100) NOT NULL,
  `Train_sttime` varchar(100) NOT NULL,
  `Train_edtime` varchar(100) NOT NULL,
  `Total_taka` int(11) NOT NULL,
  `Date` varchar(15) NOT NULL,
  `Seats` varchar(100) NOT NULL,
  `nid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `Train_no` int(11) NOT NULL,
  `Train_name` varchar(100) NOT NULL,
  `Train_seat` int(11) NOT NULL,
  `Train_start` varchar(100) NOT NULL,
  `Train_end` varchar(100) NOT NULL,
  `Train_sttime` varchar(100) NOT NULL,
  `Train_edtime` varchar(100) NOT NULL,
  `Train_day` varchar(100) NOT NULL,
  `ac_cab_seat` int(11) NOT NULL,
  `nonac_cab_seat` int(11) NOT NULL,
  `ac_seat` int(11) NOT NULL,
  `nonac_seat` int(11) NOT NULL,
  `remaining_seat` int(11) NOT NULL,
  `Date` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`Train_no`, `Train_name`, `Train_seat`, `Train_start`, `Train_end`, `Train_sttime`, `Train_edtime`, `Train_day`, `ac_cab_seat`, `nonac_cab_seat`, `ac_seat`, `nonac_seat`, `remaining_seat`, `Date`) VALUES
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '1-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '2-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '3-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '4-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '5-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '6-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '7-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '8-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '9-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '10-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '11-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '12-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '13-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '14-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '15-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '16-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '17-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '18-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '19-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '20-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '21-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '22-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '23-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '24-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '25-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '26-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '27-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '28-9-2017'),
(1, 'Turna', 500, 'Dhaka', 'Chittagong', '12:45', '17:00', '', 50, 50, 150, 250, 500, '29-9-2017'),
(1, 'Turna', 500, 'Chittagong', 'Dhaka', '12:45', '17:00', '', 50, 50, 150, 250, 500, '30-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '1-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '2-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '3-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '4-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '5-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '6-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '7-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '8-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '9-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '10-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '11-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '12-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '13-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '14-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '15-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '16-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '17-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '18-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '19-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '20-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '21-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '22-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '23-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '24-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '25-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '26-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '27-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '28-9-2017'),
(2, 'Mohanonda', 600, 'Dhaka', 'Khulna', '15:00', '19:30', '', 60, 60, 180, 300, 600, '29-9-2017'),
(2, 'Mohanonda', 600, 'Khulna', 'Dhaka', '15:00', '19:30', '', 60, 60, 180, 300, 600, '30-9-2017');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`Admin_id`);

--
-- Indexes for table `pnr`
--
ALTER TABLE `pnr`
  ADD PRIMARY KEY (`PNR_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pnr`
--
ALTER TABLE `pnr`
  MODIFY `PNR_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
