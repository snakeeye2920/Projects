/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Toufiq Siam
 */import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class connect {
     public static void main(String[] args){
         try {
             //System.out.println("Rayhan");
            Class.forName("com.mysql.jdbc.Driver");
              //System.out.println("Rayhan");
             Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/railway_reservation?zeroDateTimeBehavior=convertToNull","root","");
             Statement st =con.createStatement();
            
             String q = "Select * from admin_login";
            
             ResultSet rs = st.executeQuery(q);
             while(rs.next())
             {
             String name =rs.getString(1);
             String id =rs.getString(2);
             String p =rs.getString(3);
             System.out.println(name+" "+id+" "+p);
             }
         } 
         catch (Exception ex) 
         {
             
         }
     }
}
